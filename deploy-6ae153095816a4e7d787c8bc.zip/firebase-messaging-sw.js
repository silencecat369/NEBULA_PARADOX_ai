/* Firebase Cloud Messaging service worker.
   Deploy this file beside index.html at the published site root. */
importScripts('https://www.gstatic.com/firebasejs/10.8.0/firebase-app-compat.js');
importScripts('https://www.gstatic.com/firebasejs/10.8.0/firebase-messaging-compat.js');

firebase.initializeApp({
  apiKey: "AIzaSyBZVHVdqTaJKFAyf5tIL85scXbq_qkI1tE",
  authDomain: "nebula-paradox.firebaseapp.com",
  projectId: "nebula-paradox",
  storageBucket: "nebula-paradox.firebasestorage.app",
  messagingSenderId: "268035156132",
  appId: "1:268035156132:web:6841940d4de82dd21fde31",
  measurementId: "G-K4L0D3VB8Q"
});

const messaging = firebase.messaging();

messaging.onBackgroundMessage((payload) => {
  const notification = payload.notification || {};
  const title = notification.title || 'NP・NEBULA PARADOX';
  const options = {
    body: notification.body || 'নতুন ইভেন্ট বা আপডেট এসেছে।',
    icon: '/logo.jpg',
    data: payload.data || {},
    tag: (payload.data && payload.data.tag) || 'np-nebula-update'
  };
  self.registration.showNotification(title, options);
});

self.addEventListener('notificationclick', (event) => {
  event.notification.close();
  const target = (event.notification.data && event.notification.data.url) || '/';
  event.waitUntil((async () => {
    const clientsList = await clients.matchAll({ type: 'window', includeUncontrolled: true });
    for (const client of clientsList) {
      if ('focus' in client) {
        if ('navigate' in client && target.startsWith('/')) await client.navigate(target);
        return client.focus();
      }
    }
    if (clients.openWindow) return clients.openWindow(target);
  })());
});

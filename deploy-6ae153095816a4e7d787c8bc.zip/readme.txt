NP・NEBULA PARADOX — Google Login package

Included files: index.html and firebase-messaging-sw.js.

Before deploying:
1. In Firebase Console, open project nebula-paradox.
2. Authentication > Sign-in method > Google > Enable > Save.
3. Authentication > Settings > Authorized domains: ensure your Netlify domain is listed.
4. Check Project settings > General > your Web app config. The current site previously showed auth/invalid-api-key, so verify that the apiKey in index.html exactly matches the Web app config for this same project. Do not publish if it does not match.
5. Deploy the extracted ZIP contents so index.html is at the published root.

Important: This package removes the Phone OTP login UI/functions and adds Google redirect login. It does not change Firestore rules or the admin password. A Google sign-in can create a different Firebase UID than an existing phone-auth account. The code does not migrate, merge, or overwrite old member profiles. Preserve old accounts/data and test with a non-critical account first. Existing Firestore profile data keyed to the old Firebase UID may require a deliberate account-linking/mapping plan.


UID AUTO-SAVE UPDATE
- After Google sign-in, the site checks users/{Firebase UID}.
- If the document does not exist, it creates it with uid, displayName, photoURL, createdAt, updatedAt.
- If it already exists, it is not overwritten.
- This uses the existing nebula-paradox Firebase project and does not modify Firestore Rules or admin password.
- If profile creation is denied, check the existing Firestore Rules; do not replace them blindly.
- Google login does not automatically link a legacy phone-auth UID to the Google account.


USERNAME/PASSWORD LOGIN UPDATE
- Google Login UI and Google redirect code were replaced with username/password registration and login.
- Firebase Console > Authentication > Sign-in method: enable Email/Password before testing.
- Usernames are converted to an internal synthetic email address for Firebase Email/Password auth. No email is sent to this address; password reset is not implemented in this build.
- Existing Firestore collections/documents are not deleted or migrated. Existing Google Auth accounts are NOT automatically linked to new username/password accounts; Firebase UIDs may differ.
- Test on a duplicate/staging Netlify deploy first. Confirm Firestore Rules and all existing features before publishing.
